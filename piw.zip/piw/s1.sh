a=0
while [ true ]
do
	sh  s2.sh $a create
	a=$((a+1))
	sleep 2
	if [ $a == 6 ]
	then
		break
	fi
	echo ""
done

echo ""

while [ true ]
do
	a=$((a-1))
	if [ $a == -1 ]
		then
		break
	fi
	sh s2.sh $a remove
	sleep 2
	echo ""
done

echo This is done!!