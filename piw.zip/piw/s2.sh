# echo This is ssss $2
# para2=$2
# if [ $2 = $para2 ]
# 	then
# 	echo ohhh yess
# fi
if [ $2 = create ]
then
	echo creating file $1
	touch $1
	echo file $1 is created
fi

if  [ $2 = remove ]
then
	echo removing file $1
	rm $1
	echo file $a is removed
fi