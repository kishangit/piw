from BaseHTTPServer import HTTPServer, BaseHTTPRequestHandler
from optparse import OptionParser
import commands
import pdb
from os import curdir, sep
import cgi
import json
import time

class RequestHandler(BaseHTTPRequestHandler):
    
    def do_GET(self):
        request_path = self.path
        print(request_path)
        if request_path == "/wifi/on":
            self.wifi_on()
        elif request_path == "/wifi/off":
            self.wifi_off()
        elif request_path == "/wifi/state":
            self.wifi_state()
        elif request_path == "/wifi/wifi_list":
            self.wifi_list()
        elif request_path == "/wifi/current_wifi_network":
            self.current_wifi_network()
        elif (request_path.endswith(".js") == True) or (request_path.endswith(".css") == True):
            self.assets()

    def do_POST(self):
        request_path = self.path
        if request_path == "/wifi/connect":
            self.connect_to_wifi()
    
    do_PUT = do_POST
    do_DELETE = do_GET

    def wifi_on(self):
        html_content = commands.getstatusoutput('cat wifi_on.html')[1]
        self.wfile.write(html_content)

    def wifi_off(self):
        html_content = commands.getstatusoutput('cat wifi_off.html')[1]
        self.wfile.write(html_content)

    def wifi_state(self):
        mimetype='text/html'
        f = open(curdir + sep + 'wifi_state.html') 
        self.send_response(200)
        self.send_header('Content-type',mimetype)
        self.end_headers()
        self.wfile.write(f.read())
        f.close()

    def wifi_list(self):
        # pdb.set_trace()
        commands.getstatusoutput('sudo iwlist wlan0 scan | grep SSID >> wifi_list')
        wifis = commands.getstatusoutput("cat wifi_list | awk '{ print $1 }'")[1]
        wifis = wifis.strip().replace('\n', ' ')
        commands.getstatusoutput("rm wifi_list")
        self.wfile.write(wifis)

    def assets(self):
        if self.path.endswith("/angular.js"):
            mimetype = 'application/javascript'
            cur_path = 'assets/angular.js'

        if self.path.endswith("/jquery.js"):
            mimetype = 'application/javascript'
            cur_path = 'assets/jquery.js'
        
        if self.path.endswith("/bootstrap.js"):
            mimetype = 'application/javascript'
            cur_path = 'assets/bootstrap.js'

        if self.path.endswith("/bootstrap.css"):
            mimetype = 'text/css'
            cur_path = 'assets/bootstrap.css'

        f = open(curdir + sep + cur_path)
        self.wfile.write(f.read())
        f.close()

    def connect_to_wifi(self):
        # pdb.set_trace()
        form = cgi.FieldStorage(
                fp=self.rfile, 
                headers=self.headers,
                environ={'REQUEST_METHOD':'POST',
                         'CONTENT_TYPE':self.headers['Content-Type'],
            })
        obj = json.loads(form.value)
        # commands.getstatusoutput("sudo killall wpa_supplicant")
        wifi_name = obj['name'][1:-1]
        wifi_password = obj['password']
        com = "nmcli dev wifi connect " + wifi_name + " password " + wifi_password
        # pdb.set_trace()
        res = commands.getstatusoutput(com)
        # if (res[1].find('security.psk') != -1 or res[1].find('invalid') != -1):
        time.sleep(4)
        current_wifi = commands.getstatusoutput('iw dev wlan0 link | grep SSID:')
        if current_wifi[1] != "":
            current_wifi = current_wifi[1][7:]            
        print(form.value)
        print(com)
        # time.sleep(1)
        # res = commands.getstatusoutput("if ping -q -c 1 -W 1 8.8.8.8 >/dev/null; then echo 'IPv4 is up'; else echo 'IPv4 is down'; fi")
        # print(res)
        # if (res[1].find('down') != -1 or res[1].find('unreachable') != -1): 
        #     response_string = "Not Connected.."
        # elif (res[1].find('up') != -1):
        #     response_string = "Connected.."
        # else:
        #     response_string = "Connected.."
        # self.wfile.write(response_string)
        if current_wifi == wifi_name:
            self.wfile.write("Connected..")
        else:
            self.wfile.write("Not Connected..")

    def current_wifi_network(self):
        current_wifi = commands.getstatusoutput('iw dev wlan0 link | grep SSID:')
        # pdb.set_trace()
        if current_wifi[1] == "":
            self.wfile.write('Not Connected..')
        else:    
            current_wifi = current_wifi[1][7:]
            self.wfile.write(current_wifi)

def main():
    port = 8080
    print('Listening on localhost:%s' % port)
    server = HTTPServer(('', port), RequestHandler)
    server.serve_forever()

        
if __name__ == "__main__":
    parser = OptionParser()
    parser.usage = ("Creates an http-server that will echo out any GET or POST parameters\n"
                    "Run:\n\n"
                    "   reflect")
    (options, args) = parser.parse_args()
    
    main()