# a=5
# if [ $a == '4' ]
# then
# 	echo This is $a
# else
# 	echo ohhh yes
# fi

# a=1
# echo This is $a
# a=$((a+1))
# echo This is $a

# #Changing directory to your working directory
# File=new.txt  
# if grep -q 'kishan' "$File"; ##note the space after the string you are searching for
# then
# echo "Hooray!!It's available"
# else
# echo "Oops!!Not available"
# fi


# ping -c 5 8.8.8.8 >> ping_data
# File=ping_data  
# if grep -q '5 packets transmitted, 5 received' "$File"; ##note the space after the string you are searching for
# then
# 	echo "Network is up"
# else
# 	echo "Network is down"
# 	nmcli dev wifi connect JioFi2_502BE4 password t262j6yn0h
# fi
# rm ping_data

if ping -q -c 1 -W 1 8.8.8.8 >/dev/null; then
  echo "IPv4 is up"
else
  echo "IPv4 is down"
fi